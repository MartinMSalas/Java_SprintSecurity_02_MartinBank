package com.martintech.martin_bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MartinBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
