package com.martintech.martin_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MartinBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(MartinBankApplication.class, args);
	}

}
